import React, { useState,createContext, useReducer, useContext } from "react"
import { cartreducer } from "./Reducer";

export const cartContext = createContext();

const CartContextProvider = (props) => {


   // const [cart, setCart] = useState([])
//    localStorage.setItem("cart",JSON.stringify(cart))
//     localStorage.setItem("cart_count",cart.length)

    const [state, dispatch] = useReducer(cartreducer,{cart:[],totalPrice: 0,qty:0})
      
    return(
        // <cartContext.Provider value={[cart, setCart]}>
        //    {props.children}
        // </cartContext.Provider>

        <cartContext.Provider value={{state, dispatch}}>
            {props.children}
         </cartContext.Provider>
    )

}

export default CartContextProvider;

export const Cartstate =() =>{

    return useContext(cartContext)

}