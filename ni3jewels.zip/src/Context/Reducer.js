

export const cartreducer = (state,action) =>{

    const {cart,totalPrice,qty} = state;
    let product;
    let index;
    let updatedPrice;
    let updatedQty;
    switch(action.type){

        case "ADD_TO_CART":
            return {cart:[...cart,action.payload],qty:1}
        case "REMOVE_FROM_CART":
            return {cart:state.cart.filter((c)=>c.product_id !== action.payload.product_id),qty:0}
        // case 'INC':
        //     product = cart.find((c)=>c.product_id === action.payload.product_id);
        //     index = cart.findIndex((c)=>c.product_id === action.payload.product_id);
        //     product.qty = product.qty + 1;
        //     updatedQty = qty + 1;
        //     updatedPrice = totalPrice + action.payload.sale_price;
        //     console.log(product, totalPrice);
        //     console.log(qty);
        //     cart[index] = product;
        //     return {cart: [...cart], totalPrice: totalPrice, qty: updatedQty}
            


        default:
            return state;
    }
}