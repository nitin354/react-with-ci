import React ,{useState,useEffect}from 'react';
import { Card, Button } from "react-bootstrap";




export default function Product(props) {

const [data, setData] = useState([]);
const [offset, setOffset] = useState(0);



//console.log("data variable",dispatch);

useEffect( async () => {

    let url = `http://localhost/codeigniter/api/product/productbycategory/${props.category}/${offset}`;
   //let url = `http://localhost/codeigniter/api/product/product/${props.category}/${offset}`;
    let data1 = await fetch(url);
    let parsedata = await data1.json();
    setData(data.concat(parsedata));

    // console.log(parsedata)
    //loadproduct();

}, [offset])


function load(page){

     //console.log(page)

    setOffset(offset+1)
     //loadproduct();

}

// async function loadproduct  (){

//     //console.log(offset)

//     let url = `http://localhost/codeigniter/api/product/productbycategory/${props.category}/${offset}`;
//     let data1 = await fetch(url);
//     let parsedata = await data1.json();
//     setData(parsedata.concat(parsedata));
    

// }

   






    return (
        <div className='container my-5'>
        <h1>Products</h1>
        <div className='row'>
        {data && data.map((product,index) => 
            
                       <div key={index} className="col-md-3 my-2" >
                          <Card style={{ width: '18rem' }} >
                                <Card.Img variant="top" src={product.url} />
                                <Card.Body>
                                <Card.Title>{product.name}</Card.Title>
                                {/* <Card.Text>
                                    Some quick example text to build on the card title and make up the bulk of
                                    the card's content.
                                </Card.Text> */}
                                <Button variant="primary" onClick={() => props.addtocart()}>add to cart</Button>
                                </Card.Body>
                            </Card>
                        </div>
                        
            )}
            </div>
            <div className="col-md-12 text-center my5">
            <Button variant="dark" onClick={load}>Load More</Button>
            </div>
                               
       </div>
    )
}
