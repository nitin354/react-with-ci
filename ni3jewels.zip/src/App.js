import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Header from './components/Header';
import Product from './components/Product';
import Cart from './components/Cart';
import Login from './components/Login';
import Register from './components/Register';
import { useState } from 'react';

function App() {
  const [cart, setCart] = useState([]);
  const addtocart = (element) =>{
    
    setCart([...cart,element]);
   //setCart(cart.concat(element));
  // countries.concat(x)
    //console.log(cart);
 
   

}
  return (
    <div className="App">
      <div>
      <BrowserRouter>
     
        
        <Header  />        
        <Routes>
          
          <Route exact  path="/" element={<Product key={0}  category={2} addtocart={addtocart} />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register  />} />
          <Route  path="/engagement" element={<Product key={2}  category={2} addtocart={addtocart} />} />
          <Route  path="/wedding" element={<Product  key={8} category={8}addtocart={addtocart} />} />
          <Route  path="/cart" element={<Cart/>} />
        
        </Routes>
        
        
      </BrowserRouter>
    </div>
    </div>
  );
}

export default App;
