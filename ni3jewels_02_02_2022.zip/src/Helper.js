import { useState } from 'react'; 




 export function addtocart(element){

    let cartdata = [];

    //const [cart, setCart] = useState([]);
    let cart = [...cartdata,...element];
  
    localStorage.setItem("cart",JSON.stringify(cart))
    localStorage.setItem("cart_count",cart.length);
  
  
  }