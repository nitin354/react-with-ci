import React from 'react'
import { Card, Button  } from "react-bootstrap";

export default function Cart() {

  let cart = JSON.parse(localStorage.getItem("cart"));

  console.log(cart);
  return (
   
      <div className='container my-5'>
      <h1>Cart</h1>
      <div className='row'>
      {cart && cart?.map((product,index) => 
          
                     <div key={index} className="col-md-3 my-2" >
                        <Card style={{ width: '18rem' }} >
                              <Card.Img variant="top" src={product.url?product.url :"https://dl2vs6wk2ewna.cloudfront.net/scrap/overnight/50853-E/50853-E.side.jpg"} />
                              <Card.Body>
                              <Card.Title>{product.name}</Card.Title>
                              <Card.Title>${product.sale_price}</Card.Title>
                              {/* <Card.Text>
                                  Some quick example text to build on the card title and make up the bulk of
                                  the card's content.
                              </Card.Text> */}
                              {/* <Button variant="primary" onClick={() => addtocart(product)}>add to cart</Button> */}
                              </Card.Body>
                          </Card>
                      </div>
                      
          )}
          </div>
          {/* <div className="col-md-12 text-center my5">
          <Button variant="dark" onClick={load}>Load More</Button>
          </div> */}
                             
     </div>
  )
}

