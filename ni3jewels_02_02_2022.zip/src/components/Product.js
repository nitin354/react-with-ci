import React ,{useState,useEffect}from 'react';
import { Card, Button  } from "react-bootstrap";
import { Link } from 'react-router-dom';




export default function Product(props) {



const [data, setData] = useState([]);
const [offset, setOffset] = useState(0);


//console.log(cart);
//console.log("data variable",dispatch);

useEffect( async () => {

    let url = `http://localhost/codeigniter/api/product/productbycategory/${props.category}/${offset}`;
   //let url = `http://localhost/codeigniter/api/product/product/${props.category}/${offset}`;
    let data1 = await fetch(url);
    let parsedata = await data1.json();
    setData(data.concat(parsedata));

    // console.log(parsedata)
    //loadproduct();

}, [offset])


function load(page){

    setOffset(offset+1)

}

// async function loadproduct  (){

//     //console.log(offset)

//     let url = `http://localhost/codeigniter/api/product/productbycategory/${props.category}/${offset}`;
//     let data1 = await fetch(url);
//     let parsedata = await data1.json();
//     setData(parsedata.concat(parsedata));
    

// }

   






    return (
        <div className='container my-5'>
        <h1>{props.cat_head?props.cat_head:"Products"}</h1>
        <div className='row'>
        {data && data.map((product,index) => 
            
                       <div key={index} className="col-md-3 my-2" >
                          <Card style={{ width: '18rem' }} >
                          
                                <Card.Body>
                                <Link className="title_color" to={`/product/${ product.slug }`}><Card.Img variant="top" src={product.url?product.url :"https://dl2vs6wk2ewna.cloudfront.net/scrap/overnight/50853-E/50853-E.side.jpg"} />
                                <Card.Title className='danger title_color'>{product.name}</Card.Title>
                                <Card.Title className='danger title_color '>${product.sale_price}</Card.Title>
                                </Link>
                                {/* <Card.Text>
                                    Some quick example text to build on the card title and make up the bulk of
                                    the card's content.
                                </Card.Text> */}
                                <Button className='bg_black btn-dark' onClick={() => props.addtocart(product)}>Add To Cart</Button>
                              
                                </Card.Body>
                               
                            </Card>
                        </div>
                        
            )}
            </div>
            <div className="col-md-12 text-center my5">
            <Button variant="dark" onClick={load}>Load More</Button>
            </div>
                               
       </div>
    )
}
