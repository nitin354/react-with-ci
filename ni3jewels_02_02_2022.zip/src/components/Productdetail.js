import React,{useEffect,useState}  from 'react'
import {  Button  } from "react-bootstrap";
import { useParams } from 'react-router-dom';

export default function Productdetail(props) {

     const [product, setProduct] = useState([])


    var   {  slug } = useParams();
   
        let url = `http://localhost/codeigniter/api/product/productdetail/${slug}`;
 
        async function getData() {
            const response = await fetch(url);
            const data = await response.json();
        
            // store the data into our books variable
            setProduct(data) ;
          }


         // console.log(product);
 
useEffect(() => {

    getData();

}, [])

  return (
   
      <div className='container my-5'>
      <h1>Product Detail</h1>
      <div className='row'>
                <div key={product.slug} className="col-md-12 my-2 img_div" >
                <div className='row'>
                       
                             <div  className="col-md-6 my-2 " >
                              <img className='pdetail_img' src={product.url?product.url :"https://dl2vs6wk2ewna.cloudfront.net/scrap/overnight/50853-E/50853-E.side.jpg"} />
                              </div>
                              <div  className="col-md-6 my-5" >
                             
                              <h3 className='my-5'>{product.name}</h3>
                              <h2 className='mx-5'> ${product.sale_price}</h2>
                             
            
                              <Button  className='btn-width my-2 bg_black  btn-dark' onClick={() => props.addtocart(product)}>Add To Cart</Button>
                             
                              </div>
                          
                </div>
                </div>
          </div>
          {/* <div className="col-md-12 text-center my5">
          <Button variant="dark" onClick={load}>Load More</Button>
          </div> */}
                             
     </div>
  )
}

