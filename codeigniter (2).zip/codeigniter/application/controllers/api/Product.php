<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

//include Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Product extends REST_Controller {

    public function __construct() { 
        parent::__construct();
		
		//load Product model
        $this->load->model('product_model');
        $this->load->model('user');
    }
	
	public function product_get($offset = 0) {

		$limit =6;
	    if($offset>0){
	      	$offset = $limit * $offset;
	    }
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$Posts = $this->product_model->getRows($limit,$offset);
		//check if the Product data exists
		if(!empty($Posts)){
			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No post were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}



	public function diamond_get($offset = 0) {

		$limit =6;
	    if($offset>0){
	      	$offset = $limit * $offset;
	    }

		$Posts = $this->product_model->filterdiamonds($limit,$offset);
		//check if the Product data exists
		if(!empty($Posts)){
			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No post were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}


	public function diamondbycategory_get($offset = 0,$shape = 0) {

		  $limit =8;
		      if($offset>0){
		      	$offset = $limit * $offset;
		      }
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$posts = $this->product_model->filterdiamonds($shape,$limit,$offset);

		//echo $this->db->last_query();

		if(!empty($posts)){
			//set the response and exit
			//OK (200) being the HTTP response code
			$this->response($posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}


	public function cart_post() {
		$cartData = array();
		$cartData['user_id'] = $this->post('user_id');
		$cartData['product_id'] = $this->post('product_id');
		$cartData['type'] = $this->post('type');
		if(!empty($cartData['user_id'])  && !empty($cartData['product_id']) && !empty($cartData['type'])){
			//insert user data
			$insert = $this->product_model->cartinsert($cartData);
			$cart = $this->product_model->cartgetRows($this->post('user_id'));
			//check if the user data inserted
			if($insert){
				//set the response and exit
				$this->response([
					'status' => TRUE,
					'message' => 'Added to Cart successfully.',
					'cart_info' => $cart,
				], REST_Controller::HTTP_OK);
			}else{
				//set the response and exit
				$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
			}
        }else{
			//set the response and exit
			//BAD_REQUEST (400) being the HTTP response code
            $this->response("Provide complete user information to create.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function productdetail_get($slug = 0) {
		//otherwise single row will be returned
		$Posts = $this->product_model->getproduct($slug);
		//check if the Product data exists
		if(!empty($Posts)){
			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			$this->response([
				'status' => FALSE,
				'message' => 'No post were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}



	public function productbycategory_get($id = 0,$offset = 0) {

		  $limit =8;
		      if($offset>0){
		      	$offset = $limit * $offset;
		      }
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$posts = $this->product_model->filterweb($id,$limit,$offset);

		if(!empty($posts)){
			//set the response and exit
			//OK (200) being the HTTP response code
			$this->response($posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}


		public function searchproduct_get($keyword = 0,$offset = 0) {

		  $limit =4;

		      if($offset>0){

		      	$offset = $limit * $offset;

		      }
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$posts = $this->product_model->search($keyword,$limit,$offset);

				foreach ($posts as $key => $posting) {


			$users = $this->user->sellerdetail($posting['user_id']);
			$image = $this->product_model->getimage($posting['id']);

            $posts[$key]['product_image'] = $image['0']['product_image'];

			$posts[$key]['location'] = $users['location'];
           
            //$post = array_merge($posting,$posts);

		}
		
		//check if the Product data exists
		if(!empty($posts)){
			//OK (200) being the HTTP response code
			$this->response($posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}


	public function productimage_get($id = 0) {
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$Posts = $this->product_model->getimage($id);
		//check if the Product data exists
		if(!empty($Posts)){

			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}


	public function productvideo_get($id = 0) {

		$Posts = $this->product_model->getvideo($id);
		
		if(!empty($Posts)){

			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([/*
				'status' => FALSE,
				'message' => 'No Product were found.'*/
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	public function myproduct_get($user_id = 0) {
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$Posts = $this->product_model->myproduct($user_id);

		//$Posts['product_image'] = $this->product_model->getimage($user_id);


		foreach ($Posts as $key => $value) {
			

            //print_r($value['id']);
            $image = $this->product_model->getimage($value['id']);


            $Posts[$key]['product_image'] = $image['0']['product_image'];
            //print_r($image['0']['product_image']);             

		}
		
		//check if the Product data exists
		if(!empty($Posts)){
			//set the response and exit
			//OK (200) being the HTTP response code
			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	public function myproductwaiting_get($user_id = 0) {
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$Posts = $this->product_model->myproductwaiting($user_id);


				foreach ($Posts as $key => $value) {
			

            //print_r($value['id']);
            $image = $this->product_model->getimage($value['id']);


            $Posts[$key]['product_image'] = $image['0']['product_image'];
            //print_r($image['0']['product_image']);             

		}
		
		//check if the Product data exists
		if(!empty($Posts)){
			//set the response and exit
			//OK (200) being the HTTP response code
			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	
	public function product_post() {
		$postData = array();
		$postData['product_name'] = $this->post('product_name');
		$postData['category_id'] = $this->post('category_id');
		$postData['user_id'] = $this->post('user_id');
		$postData['price'] = $this->post('price');
		$postData['specification'] = $this->post('specification');
		$postData['description'] = $this->post('description');
		$postData['profile_id'] = $this->post('profile_id');
		$postData['stock'] = $this->post('stock');


		$product_condition =  $this->post('product_condition');
		$product_available_status =  $this->post('product_available_status');
		if(isset($product_condition)){

		$postData['product_condition'] = $this->post('product_condition');
	    
	    }

		if(isset($product_available_status)){

				$postData['product_available_status'] = $this->post('product_available_status');
		}



	if(!empty($postData['product_name']) && !empty($postData['category_id']) && !empty($postData['user_id'])){
        
            $id = $this->post('product_id');

            if(!empty($id) && isset($id)){

            $postData['status'] = 1;				
			//update Product data
			$update = $this->product_model->update($postData, $id);
			
			//check if the Product data updated
			if($update){
				//set the response and exit
				$this->response([
					'status' => TRUE,
					'message' => 'Product has been updated successfully.'
				], REST_Controller::HTTP_OK);
			}else{
				//set the response and exit
				$this->response(['status' => FALSE,
				'message' =>'Some problems occurred, please try again.'], REST_Controller::HTTP_BAD_REQUEST);
			}

            }else{

            	$postData['status'] = 1;	

               	//insert Product data
			$insert = $this->product_model->insert($postData);
			
			//check if the Product data inserted
			if($insert){
				//set the response and exit
				$this->response([
					'product_id' => $insert,
					'status' => TRUE,
					'message' => 'Product has been added successfully.'
				], REST_Controller::HTTP_OK);
			
			}else{
				//set the response and exit
				$this->response(['status' => FALSE,
				'message' =>'Some problems occurred, please try again.'], REST_Controller::HTTP_BAD_REQUEST);
			}

            }
		
        }else{
			//set the response and exit
			//BAD_REQUEST (400) being the HTTP response code
            $this->response(['status' => FALSE,
				'message' =>'Provide complete Post information to create.'], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	

	public function uploadproductimage_post()
		{       
		    $this->load->library('upload');
		    $dataInfo = array();
		     if (!empty($_FILES['profile_img']['name'])) {
		                          
		                $filesCount = count($_FILES['profile_img']['name']);
		                for($i = 0; $i < $filesCount; $i++){
		                    $_FILES['file']['name']     = $_FILES['profile_img']['name'][$i];
		                    $_FILES['file']['type']     = $_FILES['profile_img']['type'][$i];
		                    $_FILES['file']['tmp_name'] = $_FILES['profile_img']['tmp_name'][$i];
		                    $_FILES['file']['error']     = $_FILES['profile_img']['error'][$i];
		                    $_FILES['file']['size']     = $_FILES['profile_img']['size'][$i];
		                    
		                    
		                    $config['upload_path'] = './uploads/product/';
		                    $config['allowed_types'] = '*';
		                    
		                    // Load and initialize upload library
		                    $this->load->library('upload', $config);
		                    $this->upload->initialize($config);
		                    $id = $this->post('product_id');
		                    // Upload file to server
		                    if($this->upload->do_upload('file')){
		                        // Uploaded file data
		                        $fileData = $this->upload->data();
		                        $uploadData[$i]['file_name'] = $fileData['file_name'];
		                        $uploadData[$i]['created'] = date("Y-m-d H:i:s");
		                        $product_image = array("product_id"=>$id,"product_image"=>$uploadData[$i]['file_name'] );
		                              $this->db->insert('product_image', $product_image);
		                    }
		                }


		                

		         if (!empty($_FILES['profile_vid']['name'])) {
		                $config['upload_path'] = './uploads/product/';
		                // $config['allowed_types'] = 'gif|jpg|jpeg|png|doc|docx|pdf';
		                $config['allowed_types'] = '*';
		                $this->load->library('upload', $config);
		                if (!$this->upload->do_upload('profile_vid')) {
		                   
		                }else{

		                    //---- Successfully upload than add member-----
		                    $image_data = $this->upload->data();
		                    $filename = $image_data['file_name'];

		                     $product_vide = array("product_id"=>$id,"product_video"=>$filename );
				                              $this->db->insert('product_video', $product_vide);
		                }
                    }

		             
					             $this->response([
										'status' => TRUE,
										'message' => 'Product Image has been added successfully.'
									], REST_Controller::HTTP_OK);


		            }else{
					//set the response and exit
					//BAD_REQUEST (400) being the HTTP response code
		            $this->response(['status' => FALSE,
						'message' =>'Provide complete Product information to create.'], REST_Controller::HTTP_BAD_REQUEST);
				}
		}


	public function product_delete($id){
        //check whether post id is not empty
        if($id){
            //delete post
            $delete = $this->product_model->delete($id);
            
            if($delete){
                //set the response and exit
				$this->response([
					'status' => TRUE,
					'message' => 'Product has been removed successfully.'
				], REST_Controller::HTTP_OK);
            }else{
                //set the response and exit
				$this->response(['status' => FALSE,
				'message' =>'Some problems occurred, please try again.'], REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
			//set the response and exit
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
    }  

	public function productimage_delete($id){
        //check whether post id is not empty
        if($id){
            //delete post
            $delete = $this->product_model->deleteproductimage($id);
            
            if($delete){
                //set the response and exit
				$this->response([
					'status' => TRUE,
					'message' => 'Product image has been removed successfully.'
				], REST_Controller::HTTP_OK);
            }else{
                //set the response and exit
				$this->response(['status' => FALSE,
				'message' =>'Some problems occurred, please try again.'], REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
			//set the response and exit
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
    } 
   
	public function productvideo_delete($id){
        //check whether post id is not empty
        if($id){
            //delete post
            $delete = $this->product_model->deleteproductvideo($id);
            
            if($delete){
                //set the response and exit
				$this->response([
					'status' => TRUE,
					'message' => 'Product image has been removed successfully.'
				], REST_Controller::HTTP_OK);
            }else{
                //set the response and exit
				$this->response(['status' => FALSE,
				'message' =>'Some problems occurred, please try again.'], REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
			//set the response and exit
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
    } 
  // $this->product_model->deleteproductimage($id);

}

?>
