<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Product_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        //load database library
        $this->load->database();
    }

    /*
     * Fetch user data
     */
    function getRows($limit=0,$start=0){
 
            $this->db->select('*');    
            $this->db->from('products');
            $this->db->join('media', 'products.product_id = media.element_id', 'inner');
            $this->db->where(array('products.status'=> 'active'));
            $this->db->order_by("products.product_id", "DESC"); 
            $this->db->limit($limit, $start);
            $query = $this->db->get();

            //echo $query;
            return $query->result_array();
     
    }

    
       function diamondsgetRows($limit=0,$start=0){
 
            $this->db->select('*');    
            $this->db->from('diamond_data');
            $this->db->order_by("products.product_id", "DESC"); 
            $this->db->limit($limit, $start);
            $query = $this->db->get();
            return $query->result_array();
     
    }


    function filterdiamonds($shape = "",$limit,$start){
            if(!empty($shape)){
                  $this->db->select('*');    
                  $this->db->from('diamond_data');
                  $this->db->where(array('shape' => $shape));
                  $this->db->order_by("stock_no", "DESC"); 
                  $this->db->limit($limit, $start);
                  $query = $this->db->get();
                  return $query->result_array();
            }else{
                  $this->db->select('*');    
                  $this->db->from('diamond_data');
                  $this->db->order_by("stock_no", "DESC"); 
                  $this->db->limit($limit, $start);
                  $query = $this->db->get();
                  return $query->result_array();
            }
    }




        function cartgetRows($user_id=0){
 
            $this->db->select('*');    
            $this->db->from('cart');
            $this->db->where(array('user_id'=>$user_id ));
            $this->db->order_by("id", "DESC"); 
            $query = $this->db->get();
            //echo $query;
            return $query->result_array();
     
    }


function getproduct($slug = ""){

            $this->db->select('*');    
            $this->db->from('products');
            $this->db->join('media', 'products.product_id = media.element_id', 'inner');            
            $this->db->where(array('products.slug' => $slug,'products.status'=> 'active'));
             $query = $this->db->get();
           // $query = $this->db->get_where('product', array('id' => $id));
            return $query->row_array();

}

function getproductall($id = ""){

            $this->db->select('*');    
            $this->db->from('product');
            //$this->db->join('product_image', 'product.id = product_image.id', 'inner');
            $this->db->where(array('id' => $id));
             $query = $this->db->get();
           // $query = $this->db->get_where('product', array('id' => $id));
            return $query->row_array();

}

function getdeactproduct($id = ""){

            $this->db->select('*');    
            $this->db->from('product');
            //$this->db->join('product_image', 'product.id = product_image.id', 'inner');
            $this->db->where(array('id' => $id));
             $query = $this->db->get();
           // $query = $this->db->get_where('product', array('id' => $id));
            return $query->row_array();

}


        function filterweb($id = "",$limit,$start){
            if(!empty($id)){
                  $this->db->select('*');    
                  $this->db->from('products');
                  $this->db->join('media', 'products.product_id = media.element_id', 'inner');
                  $this->db->where(array('products.category_id' => $id));
                  $this->db->group_by('products.group_id'); 
                  $this->db->order_by("products.product_id", "DESC"); 
                  $this->db->limit($limit, $start);
                $query = $this->db->get();
                return $query->result_array();
            }else{
                $this->db->select('*');    
                $this->db->from('products');
                $this->db->join('media', 'products.product_id = media.element_id', 'inner');
                $this->db->group_by('products.group_id'); 
                $this->db->limit($limit, $start);
                $this->db->order_by("products.product_id", "DESC"); 
                $query = $this->db->get();
                return $query->result_array();
            }
    }



        function getactivepro($id = ""){
        if(!empty($id)){
              $this->db->select('*');    
            $this->db->from('product');
            $this->db->join('product_image', 'product.id = product_image.id', 'inner');
             $this->db->where(array('product.id' => $id,'product.status'=> 0,'product.active_status'=> 0 ));
             $this->db->order_by("product.featured", "DESC");
             $query = $this->db->get();
           // $query = $this->db->get_where('product', array('id' => $id));
            return $query->row_array();
        }else{
            $this->db->select('*');    
            $this->db->from('product');
            $this->db->join('product_image', 'product.id = product_image.id', 'inner');
          $this->db->where(array('product.status'=> 0,'product.featured'=>0,'product.active_status'=> 0 ));
            $this->db->order_by("product.id", "DESC"); 
            $query = $this->db->get();
            return $query->result();
        }
    }


    function getdeactivepro($id = ""){
        if(!empty($id)){
              $this->db->select('*');    
              $this->db->from('product');
              $this->db->join('product_image', 'product.id = product_image.id', 'inner');
              $this->db->where(array('product.status'=> 1,'product.active_status'=> 0));
              $query = $this->db->get();
           // $query = $this->db->get_where('product', array('id' => $id));
            return $query->row_array();
        }else{
              $this->db->select('*');    
              $this->db->from('product');
              $this->db->join('product_image', 'product.id = product_image.id', 'inner');
              $this->db->where(array('product.status'=> 1,'product.active_status'=> 0));
              $this->db->order_by("product.id", "DESC"); 
              $query = $this->db->get();
              return $query->result();
        }
    }


        function getadmindeactivepro($id = ""){
        if(!empty($id)){
              $this->db->select('*');    
              $this->db->from('product');
              $this->db->join('product_image', 'product.id = product_image.id', 'inner');
              $this->db->where(array('product.active_status'=> 1));
              $query = $this->db->get();
           // $query = $this->db->get_where('product', array('id' => $id));
            return $query->row_array();
        }else{
              $this->db->select('*');    
              $this->db->from('product');
              $this->db->join('product_image', 'product.id = product_image.id', 'inner');
              $this->db->where(array('product.active_status'=> 1,));
              $this->db->order_by("product.id", "DESC"); 
              $query = $this->db->get();
              return $query->result();
        }
    }

    
    function getfeaturedpro($id = ""){
        if(!empty($id)){
              $this->db->select('*');    
              $this->db->from('product');
              $this->db->join('product_image', 'product.id = product_image.id', 'inner');
              $this->db->where(array('product.status'=> 0,'active_status'=> 0));
              $query = $this->db->get();
           // $query = $this->db->get_where('product', array('id' => $id));
            return $query->row_array();
        }else{
              $this->db->select('*');    
              $this->db->from('product');
              $this->db->join('product_image', 'product.id = product_image.id', 'inner');
              $this->db->where(array('product.status'=> 0,'product.featured'=>1,'active_status'=> 0));
              $this->db->order_by("product.featured", "DESC"); 
              $query = $this->db->get();
              return $query->result();
        }
    }
 





        function filter($id = "",$limit,$start){
            if(!empty($id) && $id > 0){
                 /* $this->db->select('product.id,product.product_name,product.price,product.category_id,product.specification,product.description,product.user_id,product.profile_id,product.  status,product.featured,product.stock,product.created,product.modified,product_image.id as image_id,product_image.product_image as product_image');*/ 
                  $this->db->select('*');   
                  $this->db->from('product');
                 
                  $this->db->join('product_image', 'product.id = product_image.product_id', 'inner');
                  $this->db->where(array('product.category_id' => $id,'product.status'=> 'active'));
                  $this->db->order_by("product.featured", "DESC"); 
                  $this->db->limit($limit, $start);
                $query = $this->db->get();
                return $query->result_array();
            }else{
                /*$this->db->select('product.id,product.product_name,product.price,product.category_id,product.specification,product.description,product.user_id,product.profile_id,product.  status,product.featured,product.stock,product.created,product.  modified,product_image.id as image_id,product_image.product_image as product_image');    */

                $this->db->select('*');    
                  $this->db->from('product');
                   $this->db->join('users', 'users.user_id = product.user_id', 'Inner');
                 // $this->db->join('product_image', 'product.id = product_image.product_id', 'left');
                  $this->db->where(array('product.status'=> 0,'product.active_status'=> 0,'product.product_available_status' => 0,'users.status'=> 0));
                $this->db->limit($limit, $start);
                $this->db->order_by("product.featured", "DESC"); 
                $query = $this->db->get();
                return $query->result_array();
            }
    }


        function search($match = "",$limit,$start){
            if(!empty($match)){
                  $this->db->select('*');    
                  $this->db->from('product');
                  //$this->db->join('product_image', 'product.id = product_image.id', 'inner');
                  $this->db->where(array('status'=> 0,'active_status'=> 0));
                  
                  $this->db->like('product.product_name', $match); 
                  $this->db->or_like('product.description', $match);
                  $this->db->or_like('product.search_keyword', $match);
                  $this->db->order_by("product.featured", "DESC"); 
                  $this->db->limit($limit, $start);
                $query = $this->db->get();
                return $query->result_array();
            }
    }


        function getproductimage($id = ""){
        if(!empty($id)){
            $query = $this->db->get_where('product', array('id' => $id));
            return $query->row_array();
        }else{
            $this->db->order_by("id", "DESC"); 
            $query = $this->db->get('product');
            return $query->result_array();
        }
    }
  

      function getimage($id = ""){
        if(!empty($id)){
            $query = $this->db->get_where('product_image', array('product_id' => $id));
            return $query->result_array();
        }
    }

    function getvideo($id = ""){
        if(!empty($id)){
            $query = $this->db->get_where('product_video', array('product_id' => $id));
            return $query->result_array();
        }
    }

     function myproduct($id = ""){
        if(!empty($id)){

         /* $this->db->select('product.id,product.product_name,product.price,product.category_id,product.specification,product.description,product.user_id,product.profile_id,product.  status,product.featured,product.stock,product.created,product.  modified,product_image.id as image_id,product_image.product_image as product_image');    
                  $this->db->from('product');
                  $this->db->join('product_image', 'product.id = product_image.product_id', 'left');
                   $this->db->where(array('user_id' => $id,'status'=> 0));
                $this->db->limit($limit, $start);
                $this->db->order_by("product.featured", "DESC"); 
                $query = $this->db->get();
                return $query->result_array();
*/

            $this->db->order_by("id", "DESC"); 
            /*$this->db->join('product_image', 'product.id = product_image.id', 'inner');*/
            $query = $this->db->get_where('product', array('user_id' => $id,'status' => 0,'active_status'=> 0));
            return $query->result_array();
        }
    }

  function myproductwaiting($id = ""){
        if(!empty($id)){

      /*    $this->db->select('product.id,product.product_name,product.price,product.category_id,product.specification,product.description,product.user_id,product.profile_id,product.  status,product.featured,product.stock,product.created,product.  modified,product_image.id as image_id,product_image.product_image as product_image');    
                  $this->db->from('product');
                  $this->db->join('product_image', 'product.id = product_image.product_id', 'left');
                   $this->db->where(array('user_id' => $id,'status'=> ));
                $this->db->limit($limit, $start);
                $this->db->order_by("product.featured", "DESC"); 
                $query = $this->db->get();
*/
            $this->db->order_by("id", "DESC"); 
            $query = $this->db->get_where('product', array('user_id' => $id,'status' => 1,'active_status'=> 0));
            return $query->result_array();
        }
    }

    
    /*
     * Insert user data
     */
    public function insert($data = array()) {
        if(!array_key_exists('created', $data)){
            $data['created'] = date("Y-m-d H:i:s");
        }
        if(!array_key_exists('modified', $data)){
            $data['modified'] = date("Y-m-d H:i:s");
        }
        $insert = $this->db->insert('product', $data);
        if($insert){
            return $this->db->insert_id();
        }else{
            return false;
        }
    }


        public function cartinsert($data = array()) {
     
        $insert = $this->db->insert('cart', $data);
        if($insert){
            return $this->db->insert_id();
        }else{
            return false;
        }
    }
    
    /*
     * Update user data
     */
    public function update($data, $id) {
        if(!empty($data) && !empty($id)){
            if(!array_key_exists('modified', $data)){
                $data['modified'] = date("Y-m-d H:i:s");
            }
            $update = $this->db->update('product', $data, array('id'=>$id));
            return $update?true:false;
        }else{
            return false;
        }
    }
    
    /*
     * Delete user data
     */
    public function deleteproduct($id){
        $delete = $this->db->delete('product',array('id'=>$id));
        $delete = $this->db->delete('product_image',array('product_id'=>$id));
        return $delete?true:false;
    }

    public function deleteproductimage($id){
    
        $delete = $this->db->delete('product_image',array('id'=>$id));
        return $delete?true:false;
    }

     public function deleteproductvideo($id){
    
        $delete = $this->db->delete('product_video',array('id'=>$id));
        return $delete?true:false;
    }



       public function delete($id){
        $delete = $this->db->delete('product',array('id'=>$id));
        return $delete?true:false;
    }




}
?>