import React, { useState,createContext } from "react"

export const cartContext = createContext();

const CartContextProvider = (props) => {


    const [cart, setCart] = useState([])
   localStorage.setItem("cart",JSON.stringify(cart))
    localStorage.setItem("cart_count",cart.length)

  
      
    return(
        <cartContext.Provider value={[cart, setCart]}>
           {props.children}
        </cartContext.Provider>
    )

}

export default CartContextProvider;