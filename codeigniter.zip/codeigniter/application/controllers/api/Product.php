<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

//include Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Product extends REST_Controller {

    public function __construct() { 
        parent::__construct();
		
		//load Product model
        $this->load->model('product_model');
        $this->load->model('user');
    }
	
	public function product_get($offset = 0) {

		$limit =6;

		      if($offset>0){

		      	$offset = $limit * $offset;

		      }
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$Posts = $this->product_model->getRows($limit,$offset);
		///echo $this->db->last_query();exit;
		//check if the Product data exists
		if(!empty($Posts)){

			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No post were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}



		public function productbycategory_get($id = 0,$offset = 0) {

		  $limit =6;

		      if($offset>0){

		      	$offset = $limit * $offset;

		      }
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$posts = $this->product_model->filter($id,$limit,$offset);

		//echo $this->db->last_query();

		//print_r($post);
		foreach ($posts as $key => $posting) {


			$users = $this->user->sellerdetail($posting['user_id']);

			 $image = $this->product_model->getimage($posting['id']);


                          $username = get_user_phone($posting['user_id']);
                          $profile = get_seller_profile($posting['user_id']);


                     


            $posts[$key]['username'] = $username->username;

			$posts[$key]['profile_img'] = $profile->profile_img;


            $posts[$key]['product_image'] = $image['0']['product_image'];

			//echo $this->db->last_query();
			//print_r($users['location']);
			//$users = $this->user->sellerdetail($posting['user_id']);

			$posts[$key]['location'] = $users['location'];
           
            //$post = array_merge($posting,$posts);

		}

		//$users = $this->user->sellerdetail($post['user_id']);
		 
		//$posts = array_merge($post,$users);
		//echo $this->db->last_query();
		//check if the Product data exists
		if(!empty($posts)){
	
			//set the response and exit
			//OK (200) being the HTTP response code
			$this->response($posts, REST_Controller::HTTP_OK);
		
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}




	public function productbycategoryweb($offset = 0) {

		  $limit =3;

		      if($offset>0){

		      	$offset = $limit * $offset;

		      }
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$posts = $this->product_model->filterweb($limit,$offset);
		
		//echo $this->db->last_query();
		//check if the Product data exists
		if(!empty($posts)){


              foreach ($posts as $key => $row) {

              	echo '<div class="container-fluid bg-3 ">    
					  <div class="row">
					    <div class="col-sm-4">
					      <div class="card">
					        <img src="https://cdn.carbuzz.com/gallery-images/2019-lamborghini-huracan-performante-carbuzz-583645.jpg" class="img-responsive" style="width:100%" alt="Image">
					        <div class="card-body"> 
					           <h3>AT RS - 4000000</h3>
					              <p style="width: 71%;">Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>
					        </div>
					      </div>
					    </div>

					     <div class="col-sm-4">
					      <div class="card">
					        <img src="https://images.financialexpress.com/2019/11/2020-Kawasaki-Z900-1200.jpg?w=1200&h=800&imflag=true" class="img-responsive" style="width:100%" alt="Image">
					        <div class="card-body"> 
					           <h3>AT RS - 4000000</h3>
					              <p style="width: 71%;">Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>
					        </div>
					      </div>
					    </div>

					     <div class="col-sm-4">
					      <div class="card">
					        <img src="https://smgmedia.blob.core.windows.net/images/113420/1024/kawasaki-ninja-h2-7c9ea922af03.jpg" class="img-responsive" style="width:100%" alt="Image">
					        <div class="card-body"> 
					           <h3>AT RS - 4000000</h3>
					              <p style="width: 71%;">Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>
					        </div>
					      </div>
					    </div>
					  </div>
					</div><br><br>'; 
              	# code...
              }
         /* $html .= '<div id="post_'.$id.'" class="post">';
		    $html .= '<h1>'.$title.'</h1>';
		    $html .= '<p>'.$shortcontent.'</p>';
		    $html .= '<a href="'.$link.'" target="_blank" class="more">More</a>';
		    $html .= '</div>';*/
			//set the response and exit
			//OK (200) being the HTTP response code
			/*$this->response($posts, REST_Controller::HTTP_OK);*/
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			/*$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);*/

			echo "No Product were found.";
		}
	}


		public function searchproduct_get($keyword = 0,$offset = 0) {

		  $limit =4;

		      if($offset>0){

		      	$offset = $limit * $offset;

		      }
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$posts = $this->product_model->search($keyword,$limit,$offset);

				foreach ($posts as $key => $posting) {


			$users = $this->user->sellerdetail($posting['user_id']);

			//echo $this->db->last_query();
			//print_r($users['location']);
			//$users = $this->user->sellerdetail($posting['user_id']);
			$image = $this->product_model->getimage($posting['id']);


            $posts[$key]['product_image'] = $image['0']['product_image'];

			$posts[$key]['location'] = $users['location'];
           
            //$post = array_merge($posting,$posts);

		}
		
		//echo $this->db->last_query();
		//check if the Product data exists
		if(!empty($posts)){

			//set the response and exit
			//OK (200) being the HTTP response code
			$this->response($posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}


	public function productimage_get($id = 0) {
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$Posts = $this->product_model->getimage($id);
		
		//check if the Product data exists
		if(!empty($Posts)){

			//print_r($Posts);
			//set the response and exit
			//OK (200) being the HTTP response code
			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}


	public function productvideo_get($id = 0) {
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$Posts = $this->product_model->getvideo($id);
		
		//check if the Product data exists
		if(!empty($Posts)){



			//print_r($Posts);
			//set the response and exit
			//OK (200) being the HTTP response code
			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([/*
				'status' => FALSE,
				'message' => 'No Product were found.'*/
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	public function myproduct_get($user_id = 0) {
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$Posts = $this->product_model->myproduct($user_id);

		//$Posts['product_image'] = $this->product_model->getimage($user_id);


		foreach ($Posts as $key => $value) {
			

            //print_r($value['id']);
            $image = $this->product_model->getimage($value['id']);


            $Posts[$key]['product_image'] = $image['0']['product_image'];
            //print_r($image['0']['product_image']);             

		}
		
		//check if the Product data exists
		if(!empty($Posts)){
			//set the response and exit
			//OK (200) being the HTTP response code
			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	public function myproductwaiting_get($user_id = 0) {
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$Posts = $this->product_model->myproductwaiting($user_id);


				foreach ($Posts as $key => $value) {
			

            //print_r($value['id']);
            $image = $this->product_model->getimage($value['id']);


            $Posts[$key]['product_image'] = $image['0']['product_image'];
            //print_r($image['0']['product_image']);             

		}
		
		//check if the Product data exists
		if(!empty($Posts)){
			//set the response and exit
			//OK (200) being the HTTP response code
			$this->response($Posts, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			//NOT_FOUND (404) being the HTTP response code
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}

	
	public function product_post() {
		$postData = array();
		$postData['product_name'] = $this->post('product_name');
		$postData['category_id'] = $this->post('category_id');
		$postData['user_id'] = $this->post('user_id');
		$postData['price'] = $this->post('price');
		$postData['specification'] = $this->post('specification');
		$postData['description'] = $this->post('description');
		$postData['profile_id'] = $this->post('profile_id');
		$postData['stock'] = $this->post('stock');


		$product_condition =  $this->post('product_condition');
		$product_available_status =  $this->post('product_available_status');
		if(isset($product_condition)){

		$postData['product_condition'] = $this->post('product_condition');
	    
	    }

		if(isset($product_available_status)){

				$postData['product_available_status'] = $this->post('product_available_status');
		}



	if(!empty($postData['product_name']) && !empty($postData['category_id']) && !empty($postData['user_id'])){
        
            $id = $this->post('product_id');

            if(!empty($id) && isset($id)){

            $postData['status'] = 1;				
			//update Product data
			$update = $this->product_model->update($postData, $id);
			
			//check if the Product data updated
			if($update){
				//set the response and exit
				$this->response([
					'status' => TRUE,
					'message' => 'Product has been updated successfully.'
				], REST_Controller::HTTP_OK);
			}else{
				//set the response and exit
				$this->response(['status' => FALSE,
				'message' =>'Some problems occurred, please try again.'], REST_Controller::HTTP_BAD_REQUEST);
			}

            }else{

            	$postData['status'] = 1;	

               	//insert Product data
			$insert = $this->product_model->insert($postData);
			
			//check if the Product data inserted
			if($insert){
				//set the response and exit
				$this->response([
					'product_id' => $insert,
					'status' => TRUE,
					'message' => 'Product has been added successfully.'
				], REST_Controller::HTTP_OK);
			
			}else{
				//set the response and exit
				$this->response(['status' => FALSE,
				'message' =>'Some problems occurred, please try again.'], REST_Controller::HTTP_BAD_REQUEST);
			}

            }
		
        }else{
			//set the response and exit
			//BAD_REQUEST (400) being the HTTP response code
            $this->response(['status' => FALSE,
				'message' =>'Provide complete Post information to create.'], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	

	public function uploadproductimage_post()
		{       
		    $this->load->library('upload');
		    $dataInfo = array();
		     if (!empty($_FILES['profile_img']['name'])) {
		                          
		                $filesCount = count($_FILES['profile_img']['name']);
		                for($i = 0; $i < $filesCount; $i++){
		                    $_FILES['file']['name']     = $_FILES['profile_img']['name'][$i];
		                    $_FILES['file']['type']     = $_FILES['profile_img']['type'][$i];
		                    $_FILES['file']['tmp_name'] = $_FILES['profile_img']['tmp_name'][$i];
		                    $_FILES['file']['error']     = $_FILES['profile_img']['error'][$i];
		                    $_FILES['file']['size']     = $_FILES['profile_img']['size'][$i];
		                    
		                    
		                    $config['upload_path'] = './uploads/product/';
		                    $config['allowed_types'] = '*';
		                    
		                    // Load and initialize upload library
		                    $this->load->library('upload', $config);
		                    $this->upload->initialize($config);
		                    $id = $this->post('product_id');
		                    // Upload file to server
		                    if($this->upload->do_upload('file')){
		                        // Uploaded file data
		                        $fileData = $this->upload->data();
		                        $uploadData[$i]['file_name'] = $fileData['file_name'];
		                        $uploadData[$i]['created'] = date("Y-m-d H:i:s");
		                        $product_image = array("product_id"=>$id,"product_image"=>$uploadData[$i]['file_name'] );
		                              $this->db->insert('product_image', $product_image);
		                    }
		                }


		                

		         if (!empty($_FILES['profile_vid']['name'])) {
		                $config['upload_path'] = './uploads/product/';
		                // $config['allowed_types'] = 'gif|jpg|jpeg|png|doc|docx|pdf';
		                $config['allowed_types'] = '*';
		                $this->load->library('upload', $config);
		                if (!$this->upload->do_upload('profile_vid')) {
		                   
		                }else{

		                    //---- Successfully upload than add member-----
		                    $image_data = $this->upload->data();
		                    $filename = $image_data['file_name'];

		                     $product_vide = array("product_id"=>$id,"product_video"=>$filename );
				                              $this->db->insert('product_video', $product_vide);
		                }
                    }

		             
					             $this->response([
										'status' => TRUE,
										'message' => 'Product Image has been added successfully.'
									], REST_Controller::HTTP_OK);


		            }else{
					//set the response and exit
					//BAD_REQUEST (400) being the HTTP response code
		            $this->response(['status' => FALSE,
						'message' =>'Provide complete Product information to create.'], REST_Controller::HTTP_BAD_REQUEST);
				}
		}


	public function product_delete($id){
        //check whether post id is not empty
        if($id){
            //delete post
            $delete = $this->product_model->delete($id);
            
            if($delete){
                //set the response and exit
				$this->response([
					'status' => TRUE,
					'message' => 'Product has been removed successfully.'
				], REST_Controller::HTTP_OK);
            }else{
                //set the response and exit
				$this->response(['status' => FALSE,
				'message' =>'Some problems occurred, please try again.'], REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
			//set the response and exit
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
    }  

	public function productimage_delete($id){
        //check whether post id is not empty
        if($id){
            //delete post
            $delete = $this->product_model->deleteproductimage($id);
            
            if($delete){
                //set the response and exit
				$this->response([
					'status' => TRUE,
					'message' => 'Product image has been removed successfully.'
				], REST_Controller::HTTP_OK);
            }else{
                //set the response and exit
				$this->response(['status' => FALSE,
				'message' =>'Some problems occurred, please try again.'], REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
			//set the response and exit
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
    } 
   
	public function productvideo_delete($id){
        //check whether post id is not empty
        if($id){
            //delete post
            $delete = $this->product_model->deleteproductvideo($id);
            
            if($delete){
                //set the response and exit
				$this->response([
					'status' => TRUE,
					'message' => 'Product image has been removed successfully.'
				], REST_Controller::HTTP_OK);
            }else{
                //set the response and exit
				$this->response(['status' => FALSE,
				'message' =>'Some problems occurred, please try again.'], REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
			//set the response and exit
			$this->response([
				'status' => FALSE,
				'message' => 'No Product were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
    } 
  // $this->product_model->deleteproductimage($id);

}

?>
