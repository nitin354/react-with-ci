import Header from "./components/header/Header";
import Topnav from "./components/header/Topnav";
import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import Footer from "./components/footer/Footer";
import About from "./components/pages/About";
import "./assets/css/theme.css";
import Home from "./components/home_views/Home";
import Contact from "./components/home_views/Contact";
import Shop from "./components/home_views/Shop";
import Login from "./components/pages/Login";
import Register from "./components/pages/Register";
import Product from "./components/pages/Product";
import React ,{useState}from 'react'



function App() {

  const [cart, setCart] = useState([]);
  const addtocart = (element) =>{
    
    setCart(cart =>[...cart,element]);
   //setCart(cart.concat(element));
  // countries.concat(x)
    console.log(cart);
    localStorage.setItem("cart_data",JSON.stringify(cart));
    localStorage.setItem("cart_count",cart.length);
   

}



  return (
    <div>
      <BrowserRouter>
        <Topnav />
        <Header />        
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register  />} />
          <Route path="/product" element={<Product addtocart={addtocart} />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
