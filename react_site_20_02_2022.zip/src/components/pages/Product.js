import React ,{useState,useEffect}from 'react'
import { Card, Button } from "react-bootstrap";


export default function Product(props) {

const [data, setData] = useState("");
const [offset, setOffset] = useState(0);


useEffect( async () => {

    // let url = `http://localhost/codeigniter/api/product/product/${offset}`;
    // let data1 = await fetch(url);
    // let parsedata = await data1.json();
    // setData(parsedata);

    // console.log(parsedata)
    loadproduct();

}, [])


function load(page){

    console.log(page)

    setOffset(page+1)
    loadproduct();

}

async function loadproduct  (){

    console.log(offset)

    let url = `http://localhost/codeigniter/api/product/product/${offset}`;
    let data1 = await fetch(url);
    let parsedata = await data1.json();
    setData(parsedata.concat(parsedata));
     //setOffset(page)

}

   






    return (
        <div className='container my-5'>
        <h1>Products</h1>
        <div className='row'>
        {data && data.map((element) => 
            
                       <div className="col-md-3 my-2" key={element.product_id}>
                          <Card style={{ width: '18rem' }}>
                                <Card.Img variant="top" src={element.url} />
                                <Card.Body>
                                <Card.Title>{element.name}</Card.Title>
                                {/* <Card.Text>
                                    Some quick example text to build on the card title and make up the bulk of
                                    the card's content.
                                </Card.Text> */}
                                <Button variant="primary" onClick={() => props.addtocart(element)}>add to cart</Button>
                                </Card.Body>
                            </Card>
                        </div>
                        
            )}
            </div>
            <div class="col-md-12 text-center my5">
            <Button variant="dark" onClick={() =>load(offset)}>Load More</Button>
            </div>
                               
       </div>
    )
}
